<script>
    location.href = '<?php echo str_replace("'", "",$url); ?>';
</script>
