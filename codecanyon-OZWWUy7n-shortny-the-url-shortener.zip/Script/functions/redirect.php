<?php

if ($info['redirect'] == 1) {
    include "functions/splash.php";
} else {
    include "functions/basic_redirect.php";
}
?>